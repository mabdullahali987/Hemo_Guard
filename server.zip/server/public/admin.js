/* HemoGuard Studio UI enhancements. Progressive enhancement only: native forms and routes remain intact. */
(() => {
  'use strict';
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));
  const motionOK = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const saveFlag = (key, value) => { try { sessionStorage.setItem(key, value); } catch (_) {} };
  const readFlag = key => { try { return sessionStorage.getItem(key); } catch (_) { return null; } };
  const clearFlag = key => { try { sessionStorage.removeItem(key); } catch (_) {} };
  function toast(message) {
    const region = $('#toast-region');
    if (!region) return;
    const item = document.createElement('div');
    item.className = 'toast';
    item.setAttribute('role', 'status');
    const mark = document.createElement('span');
    mark.className = 'toast-mark';
    mark.textContent = '✦';
    const content = document.createElement('span');
    content.textContent = message;
    item.append(mark, content);
    region.append(item);
    setTimeout(() => item.remove(), 4300);
  }
  function busyForm(form) {
    form.addEventListener('submit', event => {
      if (event.defaultPrevented || !form.checkValidity()) return;
      const button = $('button[type="submit"]', form);
      if (!button || button.disabled) return;
      button.classList.add('is-submitting');
      button.disabled = true;
      button.setAttribute('aria-busy', 'true');
      // Preserve normal native form submission. A disabled button does not disable inputs.
    });
  }

  const loginForm = $('[data-login-form]');
  if (loginForm) {
    if ($('.auth-error')) clearFlag('hg-login-pending');
    const pass = $('#login-password');
    const reveal = $('[data-toggle-password]');
    const caps = $('#caps-warning');
    if (reveal && pass) {
      reveal.addEventListener('click', () => {
        const showing = pass.type === 'password';
        pass.type = showing ? 'text' : 'password';
        reveal.textContent = showing ? 'Hide' : 'Show';
        reveal.setAttribute('aria-label', showing ? 'Hide password' : 'Show password');
        reveal.setAttribute('aria-pressed', String(showing));
        pass.focus();
      });
      pass.addEventListener('keyup', e => { if (caps && e.getModifierState) caps.hidden = !e.getModifierState('CapsLock'); });
      pass.addEventListener('blur', () => { if (caps) caps.hidden = true; });
    }
    loginForm.addEventListener('submit', event => {
      if (event.defaultPrevented || !loginForm.checkValidity()) return;
      saveFlag('hg-login-pending', '1');
      const button = $('button[type="submit"]', loginForm);
      if (button) {
        $('.button-text', button).textContent = 'Verifying credentials…';
        button.classList.add('is-submitting');
        button.setAttribute('aria-busy', 'true');
        button.disabled = true;
      }
    });
  } else if ($('.admin-page') && readFlag('hg-login-pending') === '1') {
    clearFlag('hg-login-pending');
    toast('Welcome back. Your workspace is ready.');
  }

  $$('[data-enhanced-form]').forEach(busyForm);

  // Search only current table rows. This does not alter reporting counts or query the backend.
  $$('[data-table-search]').forEach(input => {
    const table = document.getElementById(input.dataset.tableSearch);
    if (!table) return;
    const rows = $$('tbody tr:not(.empty-row)', table);
    const empty = $(`[data-empty-for="${input.dataset.tableSearch}"]`);
    input.addEventListener('input', () => {
      const value = input.value.trim().toLocaleLowerCase();
      let matched = 0;
      rows.forEach(row => {
        const visible = row.textContent.toLocaleLowerCase().includes(value);
        row.hidden = !visible;
        if (visible) matched++;
      });
      if (empty) empty.hidden = !rows.length || matched > 0;
    });
  });

  const planType = $('[data-access-plan]');
  const planUnit = $('[data-access-unit]');
  if (planType && planUnit) {
    const updateUnit = () => {
      const months = $('option[value="months"]', planUnit);
      if (months) months.disabled = planType.value === 'trial';
      if (planType.value === 'trial') planUnit.value = 'days';
    };
    planType.addEventListener('change', updateUnit);
    updateUnit();
  }
  const planAction = $('[data-plan-action]');
  const planDuration = $('[data-plan-duration]');
  const renewalUnit = $('[data-plan-unit]');
  if (planAction && planDuration && renewalUnit) {
    const update = () => {
      const action = planAction.value;
      const stopped = action.startsWith('stop_');
      const isTrial = action.endsWith('_trial');
      planDuration.disabled = stopped;
      renewalUnit.disabled = stopped;
      const months = $('option[value="months"]', renewalUnit);
      if (months) months.disabled = isTrial;
      if (isTrial) renewalUnit.value = 'days';
    };
    planAction.addEventListener('change', update);
    update();
  }

  const logoutForm = $('[data-logout-form]');
  const modal = $('#logout-modal');
  if (logoutForm && modal) {
    const confirmButton = $('[data-confirm-logout]', modal);
    const stayButton = $('[data-stay]', modal);
    const dialog = $('.logout-modal', modal);
    const transition = $('#session-transition');
    const trigger = $('button[type="submit"]', logoutForm);
    let submitting = false;
    const close = () => {
      modal.hidden = true;
      document.body.style.overflow = '';
      trigger?.focus();
    };
    logoutForm.addEventListener('submit', event => {
      if (submitting) return;
      event.preventDefault();
      modal.hidden = false;
      document.body.style.overflow = 'hidden';
      stayButton?.focus();
    });
    stayButton?.addEventListener('click', close);
    modal.addEventListener('click', event => { if (event.target === modal) close(); });
    document.addEventListener('keydown', event => {
      if (modal.hidden) return;
      if (event.key === 'Escape') { event.preventDefault(); close(); }
      if (event.key === 'Tab') {
        const buttons = [stayButton, confirmButton];
        const current = buttons.indexOf(document.activeElement);
        if (event.shiftKey && current === 0) { event.preventDefault(); confirmButton?.focus(); }
        if (!event.shiftKey && current === 1) { event.preventDefault(); stayButton?.focus(); }
      }
    });
    confirmButton?.addEventListener('click', () => {
      if (submitting) return;
      submitting = true;
      modal.hidden = true;
      if (transition) transition.hidden = false;
      clearFlag('hg-login-pending');
      // The server, not this animation, revokes the session and clears the cookie.
      window.setTimeout(() => HTMLFormElement.prototype.submit.call(logoutForm), motionOK ? 620 : 0);
    });
    dialog?.addEventListener('click', event => event.stopPropagation());
  }
})();
